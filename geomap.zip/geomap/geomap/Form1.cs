﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LiveCharts.WinForms;
using System.Windows.Media;

namespace geomap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //intialization
            GeoMap geoMap = new GeoMap();
            Random random = new Random();
            //gives value
            Dictionary<string, double> values = new Dictionary<string, double>();
            values["CA"] = random.Next(0, 100);
            values["US"] = random.Next(0, 100);
            values["GB"] = random.Next(0, 100);
            //change default color
            geoMap.DefaultLandFill = new SolidColorBrush(Colors.Transparent);
            //change heat color
            GradientStopCollection collection = new GradientStopCollection();
            collection.Add(new GradientStop() { Color = System.Windows.Media.Color.FromArgb(64,64,64,0),Offset=0 });
            collection.Add(new GradientStop() { Color = System.Windows.Media.Color.FromArgb(128,128,128,0),Offset=0.5 });
            collection.Add(new GradientStop() { Color = System.Windows.Media.Color.FromArgb(255,255,255,0),Offset=1 });
            geoMap.GradientStopCollection = collection;

            //change boundary color
            geoMap.LandStroke = new SolidColorBrush(Colors.Red);


            //set value
            geoMap.HeatMap = values;
            geoMap.Hoverable = true;
            //give source the link where i get world.xml content is description
            geoMap.Source = $"{Application.StartupPath}\\world.xml";
            //set on winform
            this.Controls.Add(geoMap);
            geoMap.Dock = DockStyle.Fill;
        }
    }
}
